class Loadouts
{
	#include "usArmy\loadouts.hpp"
    #include "usMC\loadouts.hpp"
};