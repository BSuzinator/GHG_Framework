class usMC
{
    camo[] = { "mpD", "mpWD" };
    
    class Magazines
    {
        
    };
    
    // Should be 24
    #include "..\loadout_base.hpp"
    #include "soldier_f.hpp"
    #include "soldier_lat_f.hpp"
    #include "soldier_ar_f.hpp"
    #include "soldier_aar_f.hpp"
    #include "soldier_tl_f.hpp"
    #include "soldier_sl_f.hpp"
    #include "medic_f.hpp"
    #include "soldier_uav_f.hpp"
    #include "soldier_lite_f.hpp"
};