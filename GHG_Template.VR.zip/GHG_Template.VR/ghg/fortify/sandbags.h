class sandbags {
	displayName = "Sandbags";
	objects[] = {
		{"Land_BagFence_Round_F", 5},
		{"Land_BagFence_Short_F", 5},
		{"Land_BagFence_Long_F", 10},
		{"Land_BagBunker_Small_F", 25},
    };
};