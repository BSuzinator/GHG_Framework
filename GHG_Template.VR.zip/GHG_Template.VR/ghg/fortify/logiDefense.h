class logiBuildDefense {
	displayName = "Logi Defense";
	objects[] = {
		{"Land_BagFence_Round_F", 5},
		{"Land_BagFence_Short_F", 5},
		{"Land_BagFence_Long_F", 10},
		{"Land_Plank_01_4m_F", 10},
		{"Land_BagBunker_Small_F", 25},
		{"Land_CncBarrierMedium4_F", 100},
		{"Land_CncShelter_F", 25},
		{"Land_CncWall4_F", 300},
		{"Land_HBarrierTower_F", 500},
		{"Land_BlockConcrete_F", 100}
    };
};