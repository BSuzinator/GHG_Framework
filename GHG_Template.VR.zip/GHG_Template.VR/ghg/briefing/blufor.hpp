class Entry1
{
    title="Overview";
    text[]={
        "<font size='24' face='TahomaB'>Overview</font>",
        "Insurgents have been increasing their activity across the region of Chenarus. One of the local factories in the area is suspected of supplying the insurgents with explosives and other supplies, using the cover of being a mining supply company to mask their support. Each time an inspection has been scheduled has turned up nothing. That's where we come in.",
        "",
        "There will be civillians in the AO. Three civillians killed is mission fail."
    };
};

class Entry2
{
	title="Commander's Intent";
    text[]={
		"<font size='24' face='TahomaB'>Commander's Intent</font>",
		"Mount up in the planes and airdrop above the factory. The next inspection isn't scheduled for another month, so we believe the insurgents will be attempting to make the most out of this time. If you see supply caches, place charges and grab evidence of their existance, before evacuating the area and destroying all of the insurgents' supplies. Try to leave the civillian structures alone.",
		"",
		"<font size='18' face='TahomaB'>Task List</font>",
		"-Paradrop into the AO",
		"-Find evidence of insurgent supply caches",
		"-Eliminate all insurgents and caches (3x Caches)",
		"-Evade insurgent forces and fall back through the woods to the West",
		"",
		"<font size='18' face='TahomaB'>Friendly Assets</font>",
		"-1x Medical Crate + 2x Fireteam Crates / Squad",
		"-1x Demolitions Crate",
		"Crates will be dropped after you're on the ground at a green smoke on your call."
	};
};

class Entry3
{
	title="Expected Contacts";
    text[]={
		"<font size='24' face='TahomaB'>Expected Contacts</font>",
		"-Platoon+ Insurgents",
		"-Technicals",
		"-Light APCs"
	};
};