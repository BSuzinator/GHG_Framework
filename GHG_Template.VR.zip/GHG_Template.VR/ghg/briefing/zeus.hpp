class Entry1
{
    title="Zeus Instructions";
    text[]={
		"<font size='24' face='TahomaB'>Zeus Instructions</font>",
		"Leave the river clear, let the suspense build up.",
		"After the players engage, sporadically send in the reinforcements from around the AO",
		"No additional units should be spawned."
	};
};